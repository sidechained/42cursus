/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conversion_values_indices.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/18 10:08:20 by gbooth            #+#    #+#             */
/*   Updated: 2023/03/02 11:39:31 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

void	values_to_indices2(t_stack *s)
{
	int	i;
	int	j;
	int	min;
	int	idx_of_min;

	i = 0;
	while (i < s->size)
	{
		j = 0;
		min = INT_MAX;
		while (j < s->size)
		{
			if (s->u_val[j] == false && s->val[j] <= min)
			{
				min = s->val[j];
				idx_of_min = j;
			}
			j++;
		}
		s->u_val[idx_of_min] = true;
		s->ind[idx_of_min] = i;
		i++;
	}
}

void	values_to_indices(t_stack *s)
{
	s->u_val = ft_calloc(s->size, sizeof(int));
	if (!s->u_val)
		return ;
	values_to_indices2(s);
	free(s->u_val);
}

void	indices_to_values3(t_stack *s, int j, int *tmp_values)
{
	int	k;
	int	min;
	int	idx_of_min;

	min = INT_MAX;
	k = 0;
	while (k < s->size)
	{
		if (s->u_val[k] == false && tmp_values[k] <= min)
		{
			min = tmp_values[k];
			idx_of_min = k;
		}
		k++;
	}
	s->val[j] = min;
	s->u_val[idx_of_min] = true;
}

void	indices_to_values2(t_stack *s, int i, int *tmp_values)
{
	int	j;

	j = 0;
	while (j < s->size)
	{
		if (s->ind[j] == i)
			indices_to_values3(s, j, tmp_values);
		j++;
	}
}

void	indices_to_values(t_stack *s)
{
	int	*tmp_values;
	int	i;

	tmp_values = malloc(sizeof(int) * s->size);
	if (!tmp_values)
		return ;
	s->u_val = malloc(sizeof(int) * s->size);
	if (!s->u_val)
	{
		free(tmp_values);
		return ;
	}
	i = 0;
	while (i < s->size)
	{
		tmp_values[i] = s->val[i];
		s->u_val[i] = false;
		i++;
	}	
	i = 0;
	while (i++ < s->size)
		indices_to_values2(s, i, tmp_values);
	free(tmp_values);
	free(s->u_val);
}
