/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_rotate_reverse.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/12 14:38:37 by gbooth            #+#    #+#             */
/*   Updated: 2023/02/26 14:27:37 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

// rra (reverse rotate a): Shift elements of b by 1. First element becomes last.
void	reverse_rotate_a(t_stack *sa)
{
	write(1, "rra\n", 4);
	rotate_ab(sa, false);
}

// rrb (reverse rotate b): Shift elements of b by 1. First element becomes last.
void	reverse_rotate_b(t_stack *sb)
{
	write(1, "rrb\n", 4);
	rotate_ab(sb, false);
}

// rrr : rra and rrb at the same time.
void	reverse_rotate_r(t_stack *sa, t_stack *sb)
{
	write(1, "rrr\n", 4);
	rotate_ab(sa, false);
	rotate_ab(sb, false);
}
