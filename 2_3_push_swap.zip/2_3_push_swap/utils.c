/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 09:49:00 by gbooth            #+#    #+#             */
/*   Updated: 2023/03/01 12:10:23 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static long int	convert_ascii_to_integer(char *nptr)
{
	int			i;
	long int	result;

	i = 0;
	result = 0;
	while (nptr[i] != '\0')
	{	
		if (!ft_isdigit(nptr[i]))
			break ;
		result = result * 10;
		result = result + nptr[i] - '0';
		i++;
	}
	return (result);
}

long int	ft_atoi_long_int(const char *nptr)
{
	char			*nptr_;
	long int		result;
	bool			is_minus;

	is_minus = false;
	nptr_ = (char *)nptr;
	while (*nptr_ == ' ' || *nptr_ == '\t' || *nptr_ == '\r'
		|| *nptr_ == '\n' || *nptr_ == '\v' || *nptr_ == '\f')
		nptr_++;
	if (*nptr_ == '+' || *nptr_ == '-')
	{
		if (*nptr_ == '-')
			is_minus = true;
		nptr_++;
	}
	result = 0;
	result = convert_ascii_to_integer(nptr_);
	if (is_minus)
		result = result * -1;
	return (result);
}

int	get_min(t_stack *s)
{
	int	c;
	int	idx;

	idx = 0;
	c = 1;
	while (c < s->size)
	{
		if (s->ind[c] < s->ind[idx])
			idx = c;
		c++;
	}
	return (s->ind[idx]);
}

int	get_max(t_stack *s)
{
	int	c;
	int	idx;

	idx = 0;
	c = 1;
	while (c < s->size)
	{
		if (s->ind[c] > s->ind[idx])
			idx = c;
		c++;
	}
	return (s->ind[idx]);
}

bool	check_if_sorted(t_stack *sa)
{
	int	i;

	i = 0;
	while (i < sa->size)
	{
		if (sa->ind[i] != i)
			return (false);
		i++;
	}
	return (true);
}
