/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/18 09:54:56 by gbooth            #+#    #+#             */
/*   Updated: 2023/03/04 13:12:06 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <stdlib.h>
# include <stdbool.h>
# include <limits.h>
# include "libft/libft.h"

typedef struct stack
{
	int				*val;
	int				*ind;
	bool			*u_val;
	int				size;
}	t_stack;

void		print_stacks(t_stack *sa, t_stack *sb);
void		print_stack(t_stack *s, bool values_exist);

int			check_input(int argc, char **argv);

void		indices_to_values(t_stack *s);
void		values_to_indices(t_stack *s);

bool		check_if_sorted(t_stack *sa);
int			sort_radix(t_stack *sa, t_stack *sb);
void		sort_small(t_stack *a);
int			sort(t_stack *sa, t_stack *sb);

int			push_ab(t_stack *s1, t_stack *s2);
int			push_a(t_stack *sa, t_stack *sb);
int			push_b(t_stack *sa, t_stack *sb);
int			push_all_a(t_stack *sa, t_stack *sb);
int			push_all_b(t_stack *sa, t_stack *sb);

void		swap_ab(t_stack *s);
void		swap_a(t_stack *sa);
void		swap_b(t_stack *sb);
void		swap_s(t_stack *sa, t_stack *sb);

void		rotate_ab(t_stack *s, bool forwards);
void		rotate_a(t_stack *sa);
void		rotate_b(t_stack *sb);
void		rotate_r(t_stack *sa, t_stack *sb);

void		reverse_rotate_a(t_stack *sa);
void		reverse_rotate_b(t_stack *sb);
void		reverse_rotate_r(t_stack *sa, t_stack *sb);

long int	ft_atoi_long_int(const char *nptr);
int			get_min(t_stack *s);
int			get_max(t_stack *s);

#endif