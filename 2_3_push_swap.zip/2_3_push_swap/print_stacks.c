/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_stacks.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/18 10:10:17 by gbooth            #+#    #+#             */
/*   Updated: 2023/03/02 10:54:21 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

void	print_values(t_stack *s, bool values_exist)
{
	int		i;
	char	*a;

	if (values_exist)
	{
		write(1, "\n	values	: ", 11);
		i = 0;
		while (i < s->size)
		{
			a = ft_itoa(s->val[i]);
			write(1, a, ft_strlen(a));
			write(1, "\t", 1);
			i++;
		}
	}
}

void	print_stack(t_stack *s, bool values_exist)
{
	int		i;
	char	*a;

	if (s->size == 0)
	{
		write(1, "Empty!\n", 7);
		return ;
	}
	print_values(s, values_exist);
	write(1, "\n	indices	: ", 12);
	i = 0;
	while (i < s->size)
	{
		a = ft_itoa(s->ind[i]);
		write(1, a, ft_strlen(a));
		write(1, "\t", 1);
		i++;
	}
	write(1, "\n", 1);
}

void	print_stacks(t_stack *sa, t_stack *sb)
{
	write(1, " stack a: ", 10);
	print_stack(sa, true);
	write(1, " stack b: ", 1);
	print_stack(sb, false);
}
