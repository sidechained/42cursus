/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_push_all.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/12 14:38:37 by gbooth            #+#    #+#             */
/*   Updated: 2023/03/02 09:58:44 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

// push all elements from b to a
int	push_all_a(t_stack *sa, t_stack *sb)
{
	int	i;
	int	temp_size;

	i = 0;
	temp_size = sb->size;
	while (i < temp_size)
	{
		if (push_a(sa, sb))
			return (1);
		i++;
	}
	return (0);
}

// push all elements from a to b
int	push_all_b(t_stack *sa, t_stack *sb)
{
	int	i;
	int	temp_size;

	i = 0;
	temp_size = sa->size;
	while (i < temp_size)
	{
		if (push_b(sa, sb))
			return (1);
		i++;
	}
	return (0);
}
