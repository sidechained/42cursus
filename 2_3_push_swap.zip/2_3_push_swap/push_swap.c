/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/18 10:29:20 by gbooth            #+#    #+#             */
/*   Updated: 2023/03/02 11:28:25 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

int	init_stacks(char **argv, t_stack *sa, t_stack *sb)
{
	int	i;

	sa->size = 0;
	while (argv[sa->size + 1])
		sa->size++;
	sa->val = ft_calloc(sa->size, sizeof(int));
	if (!sa->val)
		return (1);
	i = 0;
	while (i < sa->size)
	{
		sa->val[i] = ft_atoi(argv[i + 1]);
		i++;
	}
	sa->ind = ft_calloc(sa->size, sizeof(int));
	if (!sa->ind)
		return (1);
	sb->size = 0;
	sb->val = NULL;
	sb->ind = NULL;
	return (0);
}

void	free_stack(t_stack *s)
{
	if (s->val)
		free(s->val);
	if (s->ind)
		free(s->ind);
	free(s);
}

int	main(int argc, char **argv)
{
	t_stack			*sa;
	t_stack			*sb;

	if (argc < 3 || check_input(argc, argv))
		return (0);
	sa = malloc(sizeof(t_stack));
	if (!sa)
		return (0);
	sb = malloc(sizeof(t_stack));
	if (!sb)
	{
		free_stack(sa);
		return (0);
	}
	if (init_stacks(argv, sa, sb))
	{
		free_stack(sa);
		return (0);
	}
	values_to_indices(sa);
	sort(sa, sb);
	indices_to_values(sa);
	free_stack(sa);
	free_stack(sb);
	return (0);
}
