/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/18 10:40:18 by gbooth            #+#    #+#             */
/*   Updated: 2023/03/02 11:28:08 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

int	sort_radix2(t_stack *sa, t_stack *sb, unsigned int max_bits)
{
	unsigned int	i;
	unsigned int	j;
	unsigned int	tmp_sa_size;

	i = 0;
	while (i < max_bits)
	{
		j = 0;
		tmp_sa_size = sa->size;
		while (j++ < tmp_sa_size && check_if_sorted(sa) == false)
		{
			if (sa->ind[0] >> i & 1)
				rotate_a(sa);
			else
				if (push_b(sa, sb))
					return (1);
		}
		while (sb->size != 0)
			if (push_a(sa, sb))
				return (0);
		i++;
	}
	return (0);
}

// pop from stack, if odd rotate, if even push to b
int	sort_radix(t_stack *sa, t_stack *sb)
{
	unsigned int	max_bits;

	max_bits = 0;
	while ((sa->size - 1) >> max_bits != 0)
		max_bits++;
	return (sort_radix2(sa, sb, max_bits));
}

// three element sort
void	sort_small(t_stack *sa)
{
	if (sa->ind[1] == get_min(sa) && sa->ind[2] == get_max(sa))
		swap_a(sa);
	if (sa->ind[1] == get_min(sa) && sa->ind[0] == get_max(sa))
		rotate_a(sa);
	if (sa->ind[2] == get_min(sa) && sa->ind[1] == get_max(sa))
		reverse_rotate_a(sa);
	if (sa->ind[0] == get_min(sa) && sa->ind[1] == get_max(sa))
	{
		swap_a(sa);
		rotate_a(sa);
	}
	if (sa->ind[2] == get_min(sa) && sa->ind[0] == get_max(sa))
	{
		swap_a(sa);
		reverse_rotate_a(sa);
	}
}

// 4 or 5 element sort
void	sort_medium(t_stack *sa, t_stack *sb)
{
	int	i;
	int	mx;

	i = 3;
	mx = sa->size - 1;
	while (i++ <= sa->size)
		push_b(sa, sb);
	sort_small(sa);
	if (sb->size == 2 && sb->ind[0] > sb->ind[1])
		swap_b(sb);
	while (sb->size != 0)
	{
		if (sb->ind[0] == sa->ind[0] - 1
			|| (sb->ind[0] == 0 && sa->ind[sa->size - 1] == mx)
			|| sb->ind[0] == sa->ind[sa->size - 1] + 1)
			push_a(sa, sb);
		else
			rotate_a(sa);
	}
	while (check_if_sorted(sa) == false)
		rotate_a(sa);
}

int	sort(t_stack *sa, t_stack *sb)
{
	if (check_if_sorted(sa))
		return (1);
	if (sa->size == 2)
		swap_a(sa);
	else if (sa->size == 3)
		sort_small(sa);
	else if (sa->size == 4 || sa->size == 5)
		sort_medium(sa, sb);
	else
		sort_radix(sa, sb);
	return (1);
}
