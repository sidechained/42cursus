/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_push.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/12 14:38:37 by gbooth            #+#    #+#             */
/*   Updated: 2023/03/02 11:51:23 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

int	resize_s_onto(t_stack *s_onto, t_stack *s_from)
{
	int	*new_indices;
	int	i;

	new_indices = ft_calloc(s_onto->size + 1, sizeof(int));
	if (!new_indices)
		return (1);
	i = 0;
	while (i < s_onto->size)
	{
		new_indices[i + 1] = s_onto->ind[i];
		i++;
	}
	new_indices[0] = s_from->ind[0];
	free(s_onto->ind);
	s_onto->ind = new_indices;
	s_onto->size++;
	return (0);
}

int	resize_s_from(t_stack *s_from)
{
	int	*new_indices;
	int	i;

	new_indices = ft_calloc(s_from->size - 1, sizeof(int));
	if (!new_indices)
		return (1);
	i = 0;
	while (i < s_from->size - 1)
	{
		new_indices[i] = s_from->ind[i + 1];
		i++;
	}
	free(s_from->ind);
	s_from->ind = new_indices;
	s_from->size--;
	return (0);
}

// s1 is stack being pushed onto, s2 is stack being pushed from
int	push_ab(t_stack *s_onto, t_stack *s_from)
{
	if (s_from == NULL)
		return (0);
	if (resize_s_onto(s_onto, s_from))
		return (1);
	if (resize_s_from(s_from))
		return (1);
	return (0);
}

// pb (push a): Pop b to a. Do nothing if a empty.
int	push_a(t_stack *sa, t_stack *sb)
{
	write(1, "pa\n", 3);
	if (push_ab(sa, sb))
		return (1);
	return (0);
}

// pb (push b): Pop a to b. Do nothing if a is empty.
int	push_b(t_stack *sa, t_stack *sb)
{
	write(1, "pb\n", 3);
	if (push_ab(sb, sa))
		return (1);
	return (0);
}
