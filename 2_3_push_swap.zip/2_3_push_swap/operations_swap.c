/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_swap.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/12 14:38:37 by gbooth            #+#    #+#             */
/*   Updated: 2023/02/26 14:27:36 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

void	swap_ab(t_stack *s)
{
	unsigned int	tmp_idx;

	if (s->size < 2)
		return ;
	tmp_idx = s->ind[0];
	s->ind[0] = s->ind[1];
	s->ind[1] = tmp_idx;
}

// sa (swap a): Swap [0][1] of a. Do nothing if size <= 1.
void	swap_a(t_stack *sa)
{
	write(1, "sa\n", 3);
	swap_ab(sa);
}

// sb (swap b): Swap [0][1] of b. Do nothing if size <= 1.
void	swap_b(t_stack *sb)
{
	write(1, "sb\n", 3);
	swap_ab(sb);
}

// ss : sa and sb at the same time.
void	swap_s(t_stack *sa, t_stack *sb)
{
	write(1, "ss\n", 3);
	swap_ab(sa);
	swap_ab(sb);
}
