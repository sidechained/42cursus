/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input_error_checking.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 13:46:49 by gbooth            #+#    #+#             */
/*   Updated: 2023/02/26 14:44:27 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

// better done after conversion, but hey
int	contains_duplicate_strings(int argc, char **argv)
{
	int	i;
	int	j;
	int	l;

	i = 0;
	while (i < argc)
	{
		j = i + 1;
		while (j < argc)
		{
			if (ft_strlen(argv[i]) > ft_strlen(argv[j]))
				l = ft_strlen(argv[i]);
			else
				l = ft_strlen(argv[j]);
			if (ft_strncmp(argv[i], argv[j], l) == 0)
				return (1);
			j++;
		}
		i++;
	}
	return (0);
}

int	contains_only_single_sign_and_digits(char *str)
{
	int		i;
	bool	contains_digit;

	contains_digit = false;
	i = 0;
	while (str[i])
	{
		if (i == 0)
		{
			if (!ft_isdigit(str[i]) && str[i] != '+' && str[i] != '-')
				return (0);
		}
		else
		{
			if (!ft_isdigit(str[i]))
				return (0);
		}
		if (ft_isdigit(str[i]))
			contains_digit = true;
		i++;
	}
	if (!contains_digit)
		return (0);
	return (1);
}

// length of INT_MAX should be 10 (TODO: replace with len of INT_MAX)
int	is_max_length_of_int(char *str)
{
	int	l;

	l = ft_strlen(str);
	if (str[0] == '-' || str [0] == '+')
		l--;
	if (l > 10)
		return (0);
	return (1);
}

int	is_in_int_min_max_range(char *str)
{
	long int	long_res;	

	long_res = ft_atoi_long_int(str);
	if (long_res < INT_MIN || long_res > INT_MAX)
		return (0);
	return (1);
}

int	check_input(int argc, char **argv)
{
	int	i;

	if (argc <= 1)
	{
		write(2, "Error\n", 6);
		return (1);
	}
	argv++;
	if (contains_duplicate_strings(argc - 1, argv))
	{
		write(2, "Error\n", 6);
		return (1);
	}
	i = 0;
	while (++i < argc - 1)
	{
		if (!contains_only_single_sign_and_digits(argv[i])
			|| !is_max_length_of_int(argv[i])
			|| !is_in_int_min_max_range(argv[i]))
		{
			write(2, "Error\n", 6);
			return (1);
		}
	}
	return (0);
}
