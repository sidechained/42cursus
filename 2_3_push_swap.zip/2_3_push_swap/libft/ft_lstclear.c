/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 21:07:50 by gbooth            #+#    #+#             */
/*   Updated: 2022/12/13 15:16:33 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

void	ft_lstclear(t_list **lst, void (*del)(void *))
{
	t_list	*lst_;

	if (lst)
	{
		while (*lst)
		{
			lst_ = (*lst)->next;
			ft_lstdelone(*lst, del);
			*lst = lst_;
		}
	}
}
