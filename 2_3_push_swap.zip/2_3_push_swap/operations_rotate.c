/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_rotate.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbooth <gbooth@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/15 09:59:36 by gbooth            #+#    #+#             */
/*   Updated: 2023/03/02 10:03:36 by gbooth           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "push_swap.h"

// would be better stated as left and right
void	rotate_forwards_backwards(t_stack *s, bool forwards, int *temp_index)
{
	int	i;

	if (forwards)
	{
		i = 0;
		*temp_index = s->ind[0];
		while (i < s->size - 1)
		{
			s->ind[i] = s->ind[i + 1];
			i++;
		}
		s->ind[s->size - 1] = *temp_index;
	}
	else
	{
		i = s->size - 1;
		*temp_index = s->ind[s->size - 1];
		while (i > 0)
		{
			s->ind[i] = s->ind[i - 1];
			i--;
		}
		s->ind[0] = *temp_index;
	}
}

void	rotate_ab(t_stack *s, bool forwards)
{
	int				*temp_index;
	int				to_add;

	if (s->size < 2)
		return ;
	temp_index = malloc(sizeof(int));
	if (!temp_index)
		return ;
	if (forwards)
		to_add = 1;
	else
		to_add = -1;
	rotate_forwards_backwards(s, forwards, temp_index);
	free(temp_index);
}

// ra (rotate a): Shift elements of stack a by 1. First element becomes last.
void	rotate_a(t_stack *sa)
{
	write(1, "ra\n", 3);
	rotate_ab(sa, true);
}

// rb (rotate b): Shift elements of stack b by 1. First element becomes last.
void	rotate_b(t_stack *sb)
{
	write(1, "rb\n", 3);
	rotate_ab(sb, true);
}

// rr : ra and rb at the same time.
void	rotate_r(t_stack *sa, t_stack *sb)
{
	write(1, "rr\n", 3);
	rotate_ab(sa, true);
	rotate_ab(sb, true);
}
