#include <stdio.h>

int main()
{
	int ox;
	int bx;
	float a;

	bx = 5;
	a = 0.5;

	ox = bx * a;

	printf("%i", ox);
}